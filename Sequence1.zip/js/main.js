$(document).ready(function(){
    $('.module-button--skipTo').on('click', function(){
        window.parent.navigateToSequence('Test-003');
    });
});